package com.example.myapplication;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

public class ViewModelGetCurrent extends ViewModel {
    MutableLiveData<String> currentNW=new MutableLiveData<>();
    public void Init(){
        currentNW.setValue(null);
    }
}
