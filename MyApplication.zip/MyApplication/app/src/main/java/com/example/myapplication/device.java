package com.example.myapplication;

public class device {
    private String name;
    private String pass;
    private String capabilities;

    public device(String name, String pass, String capabilities) {
        this.name = name;
        this.pass = pass;
        this.capabilities = capabilities;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public String getCapabilities() {
        return capabilities;
    }

    public void setCapabilities(String capabilities) {
        this.capabilities = capabilities;
    }
}
