package com.example.myapplication;

import android.Manifest;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    final int REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS = 125;
    List<ScanResult> wifiList;
    WifiManager wifi;
    ArrayList<device> values = new ArrayList<device>();
    int netCount = 0;
    ListView listView;
    WifiScanAdapter wifiScanAdapter;
    static String TAG = "WifiFragment";
    String password = null;
    Switch switchon;
    BroadcastReceiver receiver;
    DBManager db;
    List<device> arr=new ArrayList<device>();
    ViewModelGetCurrent viewModelGetCurrent;
    TextView current;
    LinearLayout lll,llc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnScan = (Button) findViewById(R.id.btnscan);
        listView = (ListView) findViewById(R.id.ListView);
        lll = (LinearLayout) findViewById(R.id.lll);
        llc = (LinearLayout) findViewById(R.id.llc);
        switchon = (Switch) findViewById(R.id.switchon);
        current=(TextView)findViewById(R.id.current);

        viewModelGetCurrent= ViewModelProviders.of(this).get(ViewModelGetCurrent.class);
        wifi = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        db=new DBManager(getApplicationContext());
        arr=db.getAll();

        //register Broadcast receiver
        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                wifiList = wifi.getScanResults();
                netCount = wifiList.size();
                Log.d("WiFi", "Total Wifi Network" + netCount);
                values.clear();
                try {
                    netCount = netCount - 1;
                    while (netCount >= 0) {
                        device d = new device(null, null, null);
                        d.setName(wifiList.get(netCount).SSID.toString());
                        d.setCapabilities(wifiList.get(netCount).capabilities);
                        Log.d("WiFi", d.getName().toString());
                        values.add(d);
                        wifiScanAdapter.notifyDataSetChanged();
                        netCount = netCount - 1;
                    }
                } catch (Exception e) {
                    Log.d("WiFi", e.getMessage());
                }
            }
        };
        registerReceiver(receiver, new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));

        wifiScanAdapter = new WifiScanAdapter(this, R.layout.network_list, values);
        listView.setAdapter(wifiScanAdapter);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            checkandAskPermission();
        } else {
            wifi.startScan();
        }

        //Check wifi enabled or not
        if (!wifi.isWifiEnabled()) {
            switchon.setChecked(false);
            lll.setVisibility(View.INVISIBLE);
            llc.setVisibility(View.INVISIBLE);
        } else {
            switchon.setChecked(true);
            lll.setVisibility(View.VISIBLE);
            llc.setVisibility(View.VISIBLE);
            wifi.startScan();
        }
        switchon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (switchon.isChecked()) {
                    wifi.setWifiEnabled(true);
                    lll.setVisibility(View.VISIBLE);
                    llc.setVisibility(View.VISIBLE);
                    wifi.startScan();
                } else {
                    wifi.setWifiEnabled(false);
                    lll.setVisibility(View.INVISIBLE);
                    llc.setVisibility(View.INVISIBLE);
                }
            }
        });
        btnScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                wifi.startScan();
            }
        });
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                final device d = values.get(position);
                boolean check = false;
                for (int i = 0; i < arr.size(); i++) {
                    if (arr.get(i).getName().equals(d.getName())) {
                        if (!connectWiFi(arr.get(i).getName(), arr.get(i).getPass(), arr.get(i).getCapabilities())) {
                            break;
                        } else {
                            check = true;
                        }
                    }
                }
                if (!check) {
                    Log.d(TAG, "Selected Network is " + d.getName());
                    LayoutInflater li = LayoutInflater.from(MainActivity.this);
                    View promptsView = li.inflate(R.layout.menuwifi, null);
                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(MainActivity.this);
                    alertDialogBuilder.setView(promptsView);
                    final EditText userInput = (EditText) promptsView.findViewById(R.id.editTextPassword);
                    TextView ssidText = (TextView) promptsView.findViewById(R.id.textViewSSID);
                    ssidText.setText("Connecting to " + d.getName());
                    TextView security = (TextView) promptsView.findViewById(R.id.textViewSecurity);
                    security.setText("Security for Network is:\n" + d.getCapabilities());
                    alertDialogBuilder
                            .setCancelable(false)
                            .setPositiveButton("OK",
                                    new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {
                                            Log.d(TAG, "Password is:" + userInput.getText());
                                            password = userInput.getText().toString();
                                            if (!connectWiFi(String.valueOf(d.getName()), password, d.getCapabilities())) {
                                                Toast.makeText(getApplicationContext(), "Connect fail!", Toast.LENGTH_LONG).show();
                                            } else {
                                                d.setPass(password);
                                                db.addStudent(d);
                                                arr.add(d);
                                            }
                                        }
                                    })
                            .setNegativeButton("Cancel",
                                    new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {
                                            dialog.cancel();
                                        }
                                    });

                    AlertDialog alertDialog = alertDialogBuilder.create();

                    alertDialog.show();

                }
            }
        });
    }

    private void checkandAskPermission() {
        List<String> permissionsNeeded = new ArrayList<String>();

        final List<String> permissionsList = new ArrayList<String>();
        if (!addPermission(permissionsList, Manifest.permission.ACCESS_COARSE_LOCATION))
            permissionsNeeded.add("Network");

        if (permissionsList.size() > 0) {
            if (permissionsNeeded.size() > 0) {
                // Need Rationale
                String message = "You need to grant access to " + permissionsNeeded.get(0);
                for (int i = 0; i < permissionsNeeded.size(); i++)
                    message = message + ", " + permissionsNeeded.get(i);
                showMessageOKCancel(message,
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                requestPermissions(permissionsList.toArray(new String[permissionsList.size()]),
                                        REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS);
                            }
                        });
                return;
            }

            requestPermissions(permissionsList.toArray(new String[permissionsList.size()]),
                    REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS);
            return;
        }
        // initVideo();
    }

    private void showMessageOKCancel(String message, DialogInterface.OnClickListener okListener) {
        new AlertDialog.Builder(MainActivity.this)
                .setMessage(message)
                .setPositiveButton("OK", okListener)
                .setNegativeButton("Cancel", okListener)
                .create()
                .show();
    }

    private boolean addPermission(List<String> permissionsList, String permission) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (this.checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
                permissionsList.add(permission);
                if (!shouldShowRequestPermissionRationale(permission))
                    return false;
            }
        }
        return true;
    }

    @Override
    protected void onDestroy() {
        unregisterReceiver(receiver);
        super.onDestroy();
    }

    public boolean connectWiFi(String SSID, String password, String Security) {
        try {

            Log.d(TAG, "Item clicked, SSID " + SSID + " Security : " + Security);

            String networkSSID = SSID;
            String networkPass = password;

            WifiConfiguration conf = new WifiConfiguration();
            conf.SSID = "\"" + networkSSID + "\"";   // Please note the quotes. String should contain ssid in quotes
            conf.status = WifiConfiguration.Status.ENABLED;
            conf.priority = 40;

            if (Security.toUpperCase().contains("WEP")) {
                Log.v("rht", "Configuring WEP");
                conf.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.NONE);
                conf.allowedProtocols.set(WifiConfiguration.Protocol.RSN);
                conf.allowedProtocols.set(WifiConfiguration.Protocol.WPA);
                conf.allowedAuthAlgorithms.set(WifiConfiguration.AuthAlgorithm.OPEN);
                conf.allowedAuthAlgorithms.set(WifiConfiguration.AuthAlgorithm.SHARED);
                conf.allowedPairwiseCiphers.set(WifiConfiguration.PairwiseCipher.CCMP);
                conf.allowedPairwiseCiphers.set(WifiConfiguration.PairwiseCipher.TKIP);
                conf.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.WEP40);
                conf.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.WEP104);

                if (networkPass.matches("^[0-9a-fA-F]+$")) {
                    conf.wepKeys[0] = networkPass;
                } else {
                    conf.wepKeys[0] = "\"".concat(networkPass).concat("\"");
                }

                conf.wepTxKeyIndex = 0;

            } else if (Security.toUpperCase().contains("WPA")) {
                Log.v(TAG, "Configuring WPA");

                conf.allowedProtocols.set(WifiConfiguration.Protocol.RSN);
                conf.allowedProtocols.set(WifiConfiguration.Protocol.WPA);
                conf.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.WPA_PSK);
                conf.allowedPairwiseCiphers.set(WifiConfiguration.PairwiseCipher.CCMP);
                conf.allowedPairwiseCiphers.set(WifiConfiguration.PairwiseCipher.TKIP);
                conf.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.WEP40);
                conf.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.WEP104);
                conf.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.CCMP);
                conf.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.TKIP);

                conf.preSharedKey = "\"" + networkPass + "\"";

            } else {
                Log.v(TAG, "Configuring OPEN network");
                conf.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.NONE);
                conf.allowedProtocols.set(WifiConfiguration.Protocol.RSN);
                conf.allowedProtocols.set(WifiConfiguration.Protocol.WPA);
                conf.allowedAuthAlgorithms.clear();
                conf.allowedPairwiseCiphers.set(WifiConfiguration.PairwiseCipher.CCMP);
                conf.allowedPairwiseCiphers.set(WifiConfiguration.PairwiseCipher.TKIP);
                conf.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.WEP40);
                conf.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.WEP104);
                conf.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.CCMP);
                conf.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.TKIP);
            }

            WifiConfiguration wifiConfig = new WifiConfiguration();
            wifiConfig.SSID = String.format("\"%s\"", networkSSID);
            wifiConfig.preSharedKey = String.format("\"%s\"", networkPass);

            // remember id
            int netId = wifi.addNetwork(wifiConfig);
            if(netId==-1){
                return false;
            }
            else {
                wifi.disconnect();
                wifi.enableNetwork(netId, true);
                wifi.reconnect();

                WifiConfiguration con = new WifiConfiguration();
                conf.SSID = "\"\"" + networkSSID + "\"\"";
                conf.preSharedKey = "\"" + networkPass + "\"";
                wifi.addNetwork(conf);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }
}