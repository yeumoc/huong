package com.example.myapplication;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class WifiScanAdapter extends ArrayAdapter<device> {
    private Context context;
    private int resource;
    private List<device> arr;

    public WifiScanAdapter(Context context, int resource, ArrayList<device> arr) {
        super(context, resource, arr);
        this.context = context;
        this.resource = resource;
        this.arr = arr;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.network_list, parent, false);
            viewHolder = new ViewHolder();
            viewHolder.ssid = (TextView) convertView.findViewById(R.id.ssid_name);

            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        device d = arr.get(position);
        viewHolder.ssid.setText(d.getName());
        return convertView;
    }

    public class ViewHolder {
        TextView ssid;
    }
}
